Publications that use CUDPP           {#cudpp_refs}
===========================

@htmlinclude doc/bib/cudpp_refs.html

