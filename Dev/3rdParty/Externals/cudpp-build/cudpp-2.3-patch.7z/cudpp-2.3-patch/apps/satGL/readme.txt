Summed Area Tables 

This application uses CUDPP to compute a depth-of-field effect in an OpenGL application by computing
a summed area table using cudppMultiscan.  

The application requires the GLEW library.  You can easily install GLEW by following the instructions
on the GLEW website [1].

[1] http://glew.sourceforge.net/install.html